import hello
print hello.hello('world!')
assert hello.hello('world!') == 'hello, world!'
