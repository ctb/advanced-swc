import hellomodule
assert hellomodule.hello('world') == 'hello, world'
print hellomodule.hello('world')
