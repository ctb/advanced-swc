#! /bin/bash
gcc -c hello.c
ar rv libhello.a hello.o
