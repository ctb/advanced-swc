import random

for i in range(0, 5000):
    print random.randint(0, 10), random.randint(5,12), random.randint(1,2)
