import swigdemo
assert swigdemo.hello("world") == "hello, world"
print swigdemo.hello("world")
