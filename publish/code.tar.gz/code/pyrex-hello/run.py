import hellomodule
assert hellomodule.hello_fn("world") == "hello, world"
print hellomodule.hello_fn("world")
